package com.example.transcamb;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Tipo_Usuario extends AppCompatActivity {

    Button btTransport, btPassageiro;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tipo__usuario);

        btPassageiro =findViewById(R.id.btnPassag);
        btTransport = findViewById(R.id.btnTranspo);

        btTransport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Tipo_Usuario.this, LoginTransportador.class);
                startActivity(intent);
            }
        });
        btPassageiro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Tipo_Usuario.this, LogInPassageirro.class);
                startActivity(intent);
            }
        });
    }
}
