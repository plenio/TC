package com.example.transcamb;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DisponibilidadeTraspo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_disponibilidade_traspo);
    }
}
