package com.example.transcamb;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;

public class LoginTransportador extends AppCompatActivity {

    private TextView CadstroTransp, recuperarsenhTransp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_transportador);

        CadstroTransp = findViewById(R.id.textregisteT_se);

        CadstroTransp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent nel = new Intent(LoginTransportador.this, CadastroTransportador.class);
                startActivity(nel);
            }
        });

    }
}
